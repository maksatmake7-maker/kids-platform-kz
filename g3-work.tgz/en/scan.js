const {chromium}=require('playwright');
const fs=require('fs');
const lang=process.argv[2]||'en';
const subj=process.argv[3].split(',');
const pages=[];
for(const s of subj){for(const f of fs.readdirSync('/home/claude/kids-platform-kz/grades/grade-3/'+s)){if(f.endsWith('.html'))pages.push('grades/grade-3/'+s+'/'+f)}}
(async()=>{const b=await chromium.launch();const res={};
for(const pg of pages){
 const ctx=await b.newContext({serviceWorkers:'block',viewport:{width:420,height:900}});const p=await ctx.newPage();
 await p.addInitScript((l)=>{try{sessionStorage.setItem('bilim_chess_pop','1');localStorage.setItem('bilim_lang_v1',l)}catch(e){}},lang);
 try{await p.goto('http://localhost:8123/'+pg,{waitUntil:'load'});await p.waitForTimeout(1800);}catch(e){res[pg]=['LOADERR'];await ctx.close();continue}
 const found=new Set();
 const grab=async()=>{const t=await p.evaluate(()=>document.body.innerText);for(const line of t.split('\n')){const l=line.trim();if(/[А-Яа-яЁё]{3}/.test(l)&&!/[әіңғүұқөһӘІҢҒҮҰҚӨҺ]/.test(l))found.add(l)}};
 await grab();
 const n=await p.evaluate(()=>window.__ac&&window.__ac.LESSONS?window.__ac.LESSONS.length:0);
 for(let li=0;li<n;li++){const ns=await p.evaluate(l=>window.__ac.LESSONS[l].steps.length,li);
  for(let si=0;si<ns;si++){try{await p.evaluate(([l,s])=>window.__ac.open(l,s),[li,si]);await p.waitForTimeout(450);await grab();
   const tabs=await p.$$('.m2-tab');for(const t of tabs.slice(0,8)){await t.click().catch(()=>{});await p.waitForTimeout(220);await grab()}}catch(e){}}}
 res[pg]=[...found];await ctx.close();}
fs.writeFileSync('/tmp/g3/en/scan_'+lang+'_'+process.argv[3].replace(/,/g,'_')+'.json',JSON.stringify(res,null,1));
let tot=0;for(const k in res)tot+=res[k].length;console.log('done',process.argv[3],'untranslated',tot);
await b.close();})();
