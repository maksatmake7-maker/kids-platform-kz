#!/bin/bash
# usage: nx.sh CUR NEXT  -> checks CUR, prints NEXT ru numbered
cd /tmp/g3/tg3
./strip.sh $1 && python3 chk.py $1 && python3 chk3.py $1
for n in 20 60 100 140 168; do echo "$n $(sed -n ${n}p ru_$1.txt|cut -c1-30) | $(sed -n ${n}p tg_$1.txt|cut -c1-30)"; done
[ -n "$2" ] && cat -n ru_$2.txt
