#!/bin/bash
# usage: strip.sh NNN  (reads tg_NNN.num, checks numbering, writes tg_NNN.txt)
cd /tmp/g3/tg3
f=tg_$1.num
awk -F'|' -v n=0 '{n++; if($1!=n){print "NUMBER MISMATCH at output line " n ": got " $1; exit 1}}' $f || exit 1
sed 's/^[0-9]*|//' $f > tg_$1.txt
echo "lines: $(wc -l < tg_$1.txt) vs ru: $(wc -l < ru_$1.txt)"
