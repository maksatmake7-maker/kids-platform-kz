import json,glob,re,sys
keys=set(json.load(open('keys.json')))
tgd=json.load(open('/tmp/g3/tgdict.json'))
a2=json.load(open('add2.json'))
pack={}
import subprocess
vals=set(tgd.values()); rukeys=set(keys)|set(tgd.keys())
for i in range(103):
    ru=open('ru_%03d.txt'%i,encoding='utf8').read().split('\n'); tg=open('tg_%03d.txt'%i,encoding='utf8').read().split('\n')
    for a,b in zip(ru,tg):
        vals.add(b); 
        if a!=b: pack[a]=b
for p,m in a2.items():
    for k,v in m.items(): vals.add(v); rukeys.add(k)
RUW=re.compile(r'(?<![А-Яа-яЁёҒғӢӣҚқӮӯҲҳҶҷ])(и|в|на|не|это|что|как|для|или|по|из|от|к|с|у|он|она|они|мы|ты|его|её|есть|был|была|были|нет|да|при|до|за|если|чтобы|где|когда|кто|чем|так|то|же|ещё|уже|можно|нужно|нельзя)(?![А-Яа-яЁёҒғӢӣҚқӮӯҲҳҶҷ])',re.I)
TGL=re.compile(r'[ҒғӢӣҚқӮӯҲҳҶҷ]')
exact={};sus={}
for f in glob.glob('scan_tg_*.json'):
    for pg,lines in json.load(open(f)).items():
        subj=pg.split('/')[2]
        for l in lines:
            if l in vals: continue
            if l in rukeys: exact.setdefault(subj,set()).add(l); continue
            if re.search(r'[ыщъэ]',l) or (RUW.search(l) and not TGL.search(l)) : sus.setdefault(subj,set()).add(l)
            elif not TGL.search(l) and not re.search(r'(?<![А-Яа-яёҒ-ҷ])(ва|дар|ба|аст|аз|бо|ин|кун|нест|ҳаст)(?![А-Яа-яё])',l): sus.setdefault(subj,set()).add(l)
print('exact',{k:len(v) for k,v in exact.items()}); print('sus',{k:len(v) for k,v in sus.items()})
json.dump({'exact':{k:sorted(v) for k,v in exact.items()},'sus':{k:sorted(v) for k,v in sus.items()}},open('left.json','w'),ensure_ascii=False,indent=0)
