import json,re,glob,os
R='/home/claude/kids-platform-kz/'
keys=json.load(open('keys.json'));mp=json.load(open('map.json'))
tgd=json.load(open('/tmp/g3/tgdict.json'))
tr={}
for i in range(103):
    ru=open('ru_%03d.txt'%i,encoding='utf8').read().split('\n'); tg=open('tg_%03d.txt'%i,encoding='utf8').read().split('\n')
    for a,b in zip(ru,tg):
        if a: tr[a]=b
allkeys={k.replace('\n',' '):k for k in keys}
a2=json.load(open('add2.json'))
S={'digital':'g3dig','english':'g3eng','estestvo':'g3est','fizra':'g3fiz','izo':'g3izo','muzyka':'g3mus','poznanie':'g3poz','samopoznanie':'g3samo','trud':'g3trud','math':'g3math'}
lit=re.compile(r'"((?:[^"\\\n]|\\.)*)"|\'((?:[^\'\\\n]|\\.)*)\'')
tot=0;unk={}
for sd,p in S.items():
    have=set(k for k in keys if p in mp[k])|set(a2.get(p,{}))
    txt=''
    for f in glob.glob(R+'grades/grade-3/%s/*.html'%sd): 
        t=open(f,encoding='utf8').read(); txt+=t
        for g in re.findall(r'src="([^"]*games/[^"]+\.js)',t):
            gp=os.path.normpath(os.path.join(os.path.dirname(f),g.split('?')[0]))
            if os.path.exists(gp): txt+=open(gp,encoding='utf8').read()
    n=0
    for m in lit.finditer(txt):
        s=m.group(1) if m.group(1) is not None else m.group(2)
        if not s or not re.search('[А-Яа-яЁё]{2}',s) or len(s)>300: continue
        s=s.replace('\\"','"').replace("\\'","'")
        if s in have: continue
        v=tr.get(s) or tgd.get(s)
        if v and v!=s:
            a2.setdefault(p,{})[s]=v; have.add(s); n+=1
        elif not v: unk.setdefault(p,set()).add(s)
    print(p,'added',n,'unknown',len(unk.get(p,())))
    tot+=n
json.dump(a2,open('add2.json','w'),ensure_ascii=False)
json.dump({p:sorted(v) for p,v in unk.items()},open('unk.json','w'),ensure_ascii=False,indent=0)
