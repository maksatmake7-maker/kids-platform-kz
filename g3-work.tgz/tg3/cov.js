const fs=require('fs'),path=require('path');
const keys=JSON.parse(fs.readFileSync('/tmp/g3/tg3/keys.json','utf8'));
const dir='/home/claude/kids-platform-kz/assets/';
const files=fs.readdirSync(dir).filter(f=>/^ui-tg.*\.js$/.test(f));
const dicts={};
for(const f of files){
  let reg=null;
  global.UI_I18N_REG=(l,o)=>{reg=o};
  try{ new Function('UI_I18N_REG',fs.readFileSync(dir+f,'utf8'))(global.UI_I18N_REG);}catch(e){console.log('ERR',f,e.message)}
  dicts[f]=reg&&reg.ex?reg.ex:{};
}
let base=dicts['ui-tg.js']||{};
let inBase=0,inAny=0;const any={};
for(const [f,d] of Object.entries(dicts)) for(const k in d) if(!(k in any)) any[k]=d[k];
for(const k of keys){ if(k in base) inBase++; if(k in any) inAny++; }
console.log('keys',keys.length,'base',Object.keys(base).length,'inBase',inBase,'inAny',inAny);
fs.writeFileSync('/tmp/g3/tg3/anytg.json',JSON.stringify(any));
