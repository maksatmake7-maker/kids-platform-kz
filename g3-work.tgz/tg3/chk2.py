import re,sys
exec(open('chk.py').read().split('bad_total')[0])
for c in sys.argv[1:]:
    ru=open(f'ru_{c}.txt',encoding='utf8').read().split('\n')
    zh=open(f'tg_{c}.txt',encoding='utf8').read().split('\n')
    for i,(a,b) in enumerate(zip(ru,zh)):
        if toks(a)!=toks(b) and '三年级' not in b and '4月' not in b:
            print(c,i+1,'|',a[:70],'|',b[:70])
