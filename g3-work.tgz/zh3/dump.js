const fs=require('fs');const A='/home/claude/kids-platform-kz/assets/';
const en={};
for(const f of fs.readdirSync(A).filter(f=>/^ui-en-(g3\w+|crsui|pz2eng)\.js$/.test(f))){
  const p=f.replace(/^ui-en-|\.js$/g,'');
  global.UI_I18N_REG=(l,o)=>{en[p]=o.ex};require(A+f);}
const base={},other={};
for(const f of fs.readdirSync(A).filter(f=>/^ui-zh(\.js|-)/.test(f))){
  global.UI_I18N_REG=(l,o)=>{const t=f==='ui-zh.js'?base:other;for(const [k,v] of Object.entries(o.ex||{}))if(!(k in t))t[k]=v};
  require(A+f);}
const map={},add={};
for(const [p,ex] of Object.entries(en))for(const k of Object.keys(ex)){
  if(k in base)continue;
  if(k in other){(add[p]=add[p]||{})[k]=other[k];continue}
  (map[k]=map[k]||[]).push(p);}
const keys=Object.keys(map);
fs.writeFileSync('keys.json',JSON.stringify(keys));fs.writeFileSync('map.json',JSON.stringify(map));fs.writeFileSync('add.json',JSON.stringify(add));
const bad=keys.filter(k=>k.includes('\n'));
console.log('keys',keys.length,'add',Object.values(add).reduce((a,m)=>a+Object.keys(m).length,0),'nl',bad.length);
for(let i=0;i*170<keys.length;i++)fs.writeFileSync('ru_'+String(i).padStart(3,'0')+'.txt',keys.slice(i*170,i*170+170).join('\n')+'\n');
console.log('chunks',Math.ceil(keys.length/170));
