import re,sys
def toks(s):
    s=s.replace('’',"'")
    return sorted(re.findall(r"[A-Za-z][A-Za-z'’\-]*|\d+",s))
bad_total=0
for c in sys.argv[1:]:
    ru=open(f'ru_{c}.txt',encoding='utf8').read().split('\n')
    zh=open(f'zh_{c}.txt',encoding='utf8').read().split('\n')
    if ru[-1]=='':ru=ru[:-1]
    if zh[-1]=='':zh=zh[:-1]
    bad=[i+1 for i,(a,b) in enumerate(zip(ru,zh)) if toks(a)!=toks(b)]
    # also question-mark / colon structure
    print(c,len(ru),len(zh),'latin/digit mismatches:',len(bad),bad[:12])
