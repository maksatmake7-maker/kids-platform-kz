#!/bin/bash
# usage: strip.sh NNN  (reads zh_NNN.num, checks numbering, writes zh_NNN.txt)
cd /tmp/g3/zh3
f=zh_$1.num
awk -F'|' -v n=0 '{n++; if($1!=n){print "NUMBER MISMATCH at output line " n ": got " $1; exit 1}}' $f || exit 1
sed 's/^[0-9]*|//' $f > zh_$1.txt
echo "lines: $(wc -l < zh_$1.txt) vs ru: $(wc -l < ru_$1.txt)"
