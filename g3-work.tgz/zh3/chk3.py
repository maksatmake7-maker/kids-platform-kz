import sys,re
for c in sys.argv[1:]:
    ru=open(f'ru_{c}.txt',encoding='utf8').read().split('\n')[:170]
    zh=open(f'zh_{c}.txt',encoding='utf8').read().split('\n')[:170]
    bad=[]
    for i,(a,b) in enumerate(zip(ru,zh)):
        q1='?' in a; q2=('？' in b) or ('?' in b)
        n1=len(re.findall(r'\d+',a)); 
        s=[]
        if q1!=q2 and not a.startswith('Привет'): s.append('Q')
        if a.startswith('Найди:') != b.startswith('找一找：'): s.append('F')
        if a.startswith('Верно') != b.startswith('正确'): s.append('V')
        if a.startswith('Неверно') != b.startswith('错误'): s.append('N')
        if s: bad.append((i+1,''.join(s)))
    print(c,bad[:15])
